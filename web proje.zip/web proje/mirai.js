
document.getElementById('search-button').addEventListener('click', function () {
    const searchValue = document.getElementById('search-input').value;
    if (searchValue) {
        console.log(`Arama yapılıyor: ${searchValue}`);
        alert(`Aranan ürün: ${searchValue}`);
    } else {
        alert('Lütfen bir ürün adı girin!');
    }
});





const dropdown = document.querySelector('.dropdown');
dropdown.addEventListener('mouseenter', function () {
    const dropdownContent = dropdown.querySelector('.dropdown-content');
    dropdownContent.style.display = 'block';
});
dropdown.addEventListener('mouseleave', function () {
    const dropdownContent = dropdown.querySelector('.dropdown-content');
    dropdownContent.style.display = 'none';
});

document.addEventListener('DOMContentLoaded', () => {
    const registerButton = document.getElementById('register-button');
    registerButton.addEventListener('click', () => {

        window.location.href = 'uye.html';
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const registerButton = document.getElementById('cart-button');
    registerButton.addEventListener('click', () => {

        window.location.href = 'sepet.html';
    });
});


document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("search-input");
    const searchButton = document.getElementById("search-button");
    const productCards = document.querySelectorAll(".aksesuar-kart");
    const cart = [];


    searchButton.addEventListener("click", () => {
        const searchTerm = searchInput.value.toLowerCase();
        productCards.forEach(card => {
            const productName = card.querySelector(".aksesuar-baslik").textContent.toLowerCase();
            if (productName.includes(searchTerm)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });




    function updateCart() {
        const cartButton = document.getElementById("cart-button");
        cartButton.textContent = `Sepet (${cart.length})`;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("search-input");
    const searchButton = document.getElementById("search-button");
    const productCards = document.querySelectorAll(".giyim-kart");
    const cart = [];


    searchButton.addEventListener("click", () => {
        const searchTerm = searchInput.value.toLowerCase();
        productCards.forEach(card => {
            const productName = card.querySelector(".giyim-baslik").textContent.toLowerCase();
            if (productName.includes(searchTerm)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });



});
document.addEventListener("DOMContentLoaded", () => {
    const addToCartButtons = document.querySelectorAll(".sepete-ekle");
    const cartButton = document.getElementById("cart-button");
    const registerButton = document.getElementById("register-button");

    addToCartButtons.forEach(button => {
        button.addEventListener("click", (event) => {

            const productCard = event.target.closest(".aksesuar-kart, .giyim-kart");
            if (!productCard) {
                console.error("Ürün kartı bulunamadı.");
                return;
            }


            let productName, productPrice, productImage;

            if (productCard.classList.contains("aksesuar-kart")) {
                productName = productCard.querySelector(".aksesuar-baslik").textContent;
            } else if (productCard.classList.contains("giyim-kart")) {
                productName = productCard.querySelector(".giyim-baslik").textContent;
            }

            productPrice = productCard.querySelector(".yeni-fiyat").textContent;
            productImage = productCard.querySelector("img").src;

            const product = { name: productName, price: productPrice, image: productImage };


            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart.push(product);
            localStorage.setItem("cart", JSON.stringify(cart));

            alert(`${productName} sepete eklendi.`);
            updateCartCount();
        });
    });


    function updateCartCount() {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        const cartButtonSpan = cartButton.querySelector("span");

        if (cartButtonSpan) {
            cartButtonSpan.textContent = `Sepet (${cart.length})`;
        } else {
            const span = document.createElement("span");
            span.textContent = `Sepet (${cart.length})`;
            cartButton.appendChild(span);
        }
    }

    updateCartCount();
});


document.addEventListener("DOMContentLoaded", () => {
    const cartItemsContainer = document.getElementById("cart-items-list");
    const totalPriceElement = document.getElementById("total-price");
    const checkoutButton = document.getElementById("checkout-button");

    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let totalPrice = 0;

    const updateCartDisplay = () => {
        cartItemsContainer.innerHTML = "";
        totalPrice = 0;

        cart.forEach((item, index) => {
            const cartItem = document.createElement("tr");
            cartItem.className = "cart-item";
            cartItem.innerHTML = `
                <td><img src="${item.image}" alt="Ürün Görseli" style="width: 100px; height: 100px;"></td>
                <td>${item.name}</td>
                <td>${item.price}</td>
                <td><button class="remove-item" data-index="${index}">Sil</button></td>
            `;
            cartItemsContainer.appendChild(cartItem);


            totalPrice += parseFloat(item.price.replace("TL", "").replace(",", "."));
        });

        // cart.forEach((item, index) => {
        //     const cartItem = document.createElement("div");
        //     cartItem.className = "cart-item";
        //     cartItem.innerHTML = `
        //         <div>
        //             <img src="${item.image}" alt="${item.name}" style="width: 100px; height: 100px;">
        //             <span>${item.name}</span>
        //         </div>
        //         <div>
        //             <span>${item.price}</span>
        //             <button class="remove-item" data-index="${index}">Sil</button>
        //         </div>
        //     `;
        //     cartItemsContainer.appendChild(cartItem);


        //     totalPrice += parseFloat(item.price.replace("TL", "").replace(",", "."));
        // });

        totalPriceElement.textContent = `${totalPrice.toFixed(2)} TL`;


        const removeButtons = document.querySelectorAll(".remove-item");
        removeButtons.forEach(button => {
            button.addEventListener("click", (event) => {
                const itemIndex = event.target.getAttribute("data-index");
                cart.splice(itemIndex, 1);
                localStorage.setItem("cart", JSON.stringify(cart));
                updateCartDisplay();
            });
        });
    };

    updateCartDisplay();


    checkoutButton.addEventListener("click", () => {
        if (cart.length > 0) {
            alert("Satın alma işleminiz başarılı!");
            localStorage.removeItem("cart");
            cart = [];
            updateCartDisplay();
        } else {
            alert("Sepetiniz boş!");
        }
    });
});



document.addEventListener("DOMContentLoaded", () => {
    const navToggle = document.createElement("button");
    navToggle.textContent = "☰";
    navToggle.style.cssText = `
        display: none;
        background: none;
        color: white;
        font-size: 2rem;
        border: none;
        cursor: pointer;
    `;

    const nav = document.querySelector("nav");
    document.querySelector("header").insertBefore(navToggle, nav);

    navToggle.addEventListener("click", () => {
        nav.style.display = nav.style.display === "flex" ? "none" : "flex";
    });

    window.addEventListener("resize", () => {
        if (window.innerWidth > 768) {
            nav.style.display = "flex";
            navToggle.style.display = "none";
        } else {
            nav.style.display = "none";
            navToggle.style.display = "block";
        }
    });

    window.dispatchEvent(new Event("resize"));
});


